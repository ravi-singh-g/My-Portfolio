import { useRef } from 'react'
import { motion } from 'framer-motion'
import { resume } from '../data/resume'
import { SectionHead } from './About'

function TiltCard({ children, accent }) {
  const ref = useRef(null)

  const onMove = (e) => {
    const el = ref.current
    if (!el) return
    const r = el.getBoundingClientRect()
    const px = (e.clientX - r.left) / r.width
    const py = (e.clientY - r.top) / r.height
    el.style.transform = `perspective(950px) rotateX(${(0.5 - py) * 9}deg) rotateY(${(px - 0.5) * 11}deg) translateY(-5px)`
    el.style.setProperty('--mx', `${px * 100}%`)
    el.style.setProperty('--my', `${py * 100}%`)
  }

  const onLeave = () => {
    const el = ref.current
    if (!el) return
    el.style.transform = 'perspective(950px) rotateX(0deg) rotateY(0deg) translateY(0)'
  }

  return (
    <motion.article
      ref={ref}
      className="tilt-card card"
      style={{ '--accent': accent }}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.55 }}
    >
      {children}
    </motion.article>
  )
}

export default function Projects() {
  return (
    <section className="section" id="projects">
      <SectionHead kicker="03 · work" title="Featured Projects" />

      <div className="projects-grid">
        {resume.projects.map((p) => (
          <TiltCard key={p.name} accent={p.accent}>
            <div className="proj-top">
              <span className="proj-kind">{p.kind}</span>
              <div className="proj-links">
                {p.links.github && p.links.github !== '#' && (
                  <a href={p.links.github} target="_blank" rel="noreferrer" aria-label={`${p.name} on GitHub`}>
                    <svg viewBox="0 0 24 24" width="17" height="17" fill="currentColor">
                      <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12" />
                    </svg>
                  </a>
                )}
                {p.links.demo && p.links.demo !== '#' && (
                  <a href={p.links.demo} target="_blank" rel="noreferrer" aria-label={`${p.name} live demo`}>
                    <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                      <path d="M15 3h6v6" />
                      <path d="M10 14L21 3" />
                    </svg>
                  </a>
                )}
              </div>
            </div>

            <h3 className="proj-name">{p.name}</h3>
            <p className="proj-blurb">{p.blurb}</p>

            <ul className="proj-highlights">
              {p.highlights.map((h) => (
                <li key={h}>{h}</li>
              ))}
            </ul>

            <div className="chips proj-tech">
              {p.tech.map((t) => (
                <span key={t} className="chip">
                  {t}
                </span>
              ))}
            </div>
          </TiltCard>
        ))}
      </div>
    </section>
  )
}
